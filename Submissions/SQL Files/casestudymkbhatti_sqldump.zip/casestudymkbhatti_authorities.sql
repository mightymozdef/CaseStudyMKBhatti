INSERT INTO casestudymkbhatti.authorities (authority, username) VALUES ('user', 'bobbbb');
INSERT INTO casestudymkbhatti.authorities (authority, username) VALUES ('user', 'bobbbb123123');
INSERT INTO casestudymkbhatti.authorities (authority, username) VALUES ('user', 'moez');
INSERT INTO casestudymkbhatti.authorities (authority, username) VALUES ('user', 'scoob');
INSERT INTO casestudymkbhatti.authorities (authority, username) VALUES ('user', 'scooby');